dir !
this is readme file. please read this file to use proteus file.
all question which requet design in proteus be designed in only a file. 
in proteus file be slit to region. each question have a region to simulation.

how to use !
If you want simulation for a question, fowllowing this way:
1. add hex file to microcontroller 8051
2. you should desable switch which is unneccessary region. And you must enable switch in region you want to simulation.

Thanks for watching !
Group 09, remenber:
1. Nguyen Thanh Toan
2. Phan Van Thinh 
3. Mai The Truyen

NOTE: If source code asm error. You can get it in github by link: https://github.com/ThToan2510/BTL_VXL
or if you have github in your windown, you can clone code with command: git clone https://github.com/ThToan2510/BTL_VXL.git
